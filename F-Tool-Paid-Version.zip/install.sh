echo "\033[38;5;129mupdating..."
apt -y update
apt -y upgrade
yum -y update
yum -y upgrade
echo "\033[38;5;129mdone."

echo "\033[38;5;129minstalling... ['screen', 'nodejs']"
apt -y install screen nodejs
yum -y install screen nodejs
echo "\033[38;5;129mdone."

echo "\033[38;5;129minstalling... ['randomstring', 'request']"
npm i randomstring
npm i request
echo "\033[38;5;129mdone."

echo "\033[38;5;129minstalling... ['httpx', 'requests', 'colorama', 'speedtest-cli']"
pip3 install -r requirements.txt
echo "\033[38;5;129mdone."

echo "\033[38;5;129mExecuting..."
python3 F-Tool.py
